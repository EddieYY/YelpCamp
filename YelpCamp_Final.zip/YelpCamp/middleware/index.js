
var Campground = require("../models/campground");
var Comment = require("../models/comment");

var middlewareObj = {};


middlewareObj.isLoggedIn = function(req, res, next){
     if(req.isAuthenticated()){
        return next();
    }
    req.flash("error", "請先登入！")
    res.redirect("/login");
}

middlewareObj.checkCommentOwnership = function (req, res, next){
    if(req.isAuthenticated()){
        Comment.findById(req.params.comment_id, function(err, FoundComment){
            if(err){
                req.flash("error", "找不到您所選的！！");
                res.redirect("back");
            }else{
                if(FoundComment.author.id.equals(req.user._id)){
                    next();
                }else{
                    req.flash("error", "沒有修改權限！！");
                    res.redirect("back");
                }
            }
        })
    }else{
        req.flash("error", "請先登入！！");
         res.redirect("back");
    }
}

middlewareObj.checkCampgroundOwnership = function (req, res, next){
    if(req.isAuthenticated()){
        Campground.findById(req.params.id, function(err, FoundCampground){
            if(err){
                req.flash("error", "找不到您所選的！！");
                res.redirect("back");
            }else{
                if(FoundCampground.author.id.equals(req.user._id)){
                    next();
                }else{
                    req.flash("error", "沒有修改權限！！");
                    res.redirect("back");
                }
            }
        })
    }else{
         req.flash("error", "請先登入！！");
         res.redirect("back");
    }
}


module.exports = middlewareObj;